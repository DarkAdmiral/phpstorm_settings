import React from 'react';
import ReactDOM from 'react-dom';

class MainFrame extends React.Component {
  render() {
    return (
      <div id="mainframe">

      </div>
    )
  }
}

export default MainFrame;
